// ============================================================
// КАР-точки — маленькие помощники интерфейса
// ============================================================
(function () {
  'use strict';

  // el('div', {class:'x', onclick: fn}, [children|string])
  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      for (const k in attrs) {
        const v = attrs[k];
        if (v === null || v === undefined || v === false) continue;
        if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
        else if (k === 'html') node.innerHTML = v;
        else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
        else node.setAttribute(k, v === true ? '' : v);
      }
    }
    if (children !== undefined && children !== null) {
      (Array.isArray(children) ? children : [children]).forEach(ch => {
        if (ch === null || ch === undefined || ch === false) return;
        node.appendChild(typeof ch === 'string' || typeof ch === 'number' ? document.createTextNode(String(ch)) : ch);
      });
    }
    return node;
  }

  function toast(msg, type) {
    const root = document.getElementById('toasts');
    const t = el('div', { class: 'toast ' + (type || '') }, msg);
    root.appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => {
      t.classList.remove('show');
      setTimeout(() => t.remove(), 350);
    }, 2600);
  }

  // Модальное окно. content — узел; возвращает {close}
  function modal(content, opts) {
    opts = opts || {};
    const root = document.getElementById('modalRoot');
    const box = el('div', { class: 'modal-box' + (opts.wide ? ' wide' : '') }, content);
    const overlay = el('div', { class: 'modal-overlay' }, box);
    function close() {
      overlay.classList.remove('open');
      document.removeEventListener('keydown', onKey);
      setTimeout(() => overlay.remove(), 260);
    }
    function onKey(e) { if (e.key === 'Escape') close(); }
    overlay.addEventListener('click', e => { if (e.target === overlay && !opts.sticky) close(); });
    document.addEventListener('keydown', onKey);
    root.appendChild(overlay);
    requestAnimationFrame(() => requestAnimationFrame(() => overlay.classList.add('open')));
    return { close, box };
  }

  // Красивое подтверждение вместо window.confirm
  function confirmDialog(title, text, okLabel, danger) {
    return new Promise(resolve => {
      let m;
      const content = el('div', null, [
        el('h3', { class: 'modal-title' }, title),
        text ? el('p', { class: 'modal-text' }, text) : null,
        el('div', { class: 'modal-actions' }, [
          el('button', { class: 'btn ghost', onclick: () => { m.close(); resolve(false); } }, 'Отмена'),
          el('button', {
            class: 'btn ' + (danger ? 'danger' : 'primary'),
            onclick: () => { m.close(); resolve(true); },
          }, okLabel || 'Ок'),
        ]),
      ]);
      m = modal(content);
    });
  }

  function spinner(size) {
    return el('div', { class: 'spinner', style: size ? { width: size + 'px', height: size + 'px' } : null });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function plural(n, one, few, many) {
    if (n % 10 === 1 && n % 100 !== 11) return one;
    if ([2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100)) return few;
    return many;
  }

  const CROW_SVG = '<svg viewBox="0 0 256 256" aria-hidden="true"><g fill="currentColor"><circle cx="112" cy="102" r="54"/><path d="M 152 84 Q 196 88 220 101 Q 196 114 152 120 Q 162 101 152 84 Z"/><circle cx="124" cy="88" r="10" fill="var(--bg)"/><circle cx="127" cy="86" r="4.5"/><circle cx="76" cy="196" r="13"/><circle cx="120" cy="196" r="13" opacity="0.62"/><circle cx="164" cy="196" r="13" opacity="0.3"/></g></svg>';

  window.UI = { el, toast, modal, confirmDialog, spinner, escapeHtml, plural, CROW_SVG };
})();
